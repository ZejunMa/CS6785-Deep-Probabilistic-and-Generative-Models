#!/usr/bin/env bash
zip -r hw2.zip codebase/utils.py codebase/models/vae.py codebase/models/gmvae.py codebase/models/ssvae.py codebase/models/fsvae.py
